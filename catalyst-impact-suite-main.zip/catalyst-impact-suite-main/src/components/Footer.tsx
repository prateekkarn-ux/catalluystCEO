import { Button } from "@/components/ui/button";
import { MapPin, Download } from "lucide-react";
import { Link } from "react-router-dom";
import catallystLogo from "@/assets/catallyst-logo.png";

interface FooterProps {
  onOpenBrochure: () => void;
  onOpenPlaybook: () => void;
  onOpenFramework: () => void;
  onOpenBoardBrief: () => void;
}

export const Footer = ({ onOpenBrochure, onOpenPlaybook, onOpenFramework, onOpenBoardBrief }: FooterProps) => {
  return (
    <footer className="bg-primary text-primary-foreground py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <img src={catallystLogo} alt="Catallyst" className="h-8 w-auto mb-4" />
            <div className="flex items-start gap-2 text-primary-foreground/80">
              <MapPin className="w-5 h-5 mt-1 flex-shrink-0" />
              <div className="text-sm">
                <p>Catallyst Executive Education Institute (CEEI)</p>
                <p>9th Floor, Platina, G Block, Plot C 59</p>
                <p>Bandra Kurla Complex</p>
                <p>Mumbai - 400 051, India</p>
              </div>
            </div>
          </div>

          {/* Downloadable Resources */}
          <div>
            <h4 className="font-semibold mb-4 flex items-center gap-2">
              <Download className="w-5 h-5" />
              Downloadable Resources
            </h4>
            <ul className="space-y-2 text-sm text-primary-foreground/80">
              <li>
                <Button
                  variant="link"
                  className="text-primary-foreground/80 hover:text-accent p-0 h-auto"
                  onClick={onOpenBrochure}
                >
                  "Lead the Shift, Shape What's Next" Brochure
                </Button>
              </li>
              <li>
                <Button
                  variant="link"
                  className="text-primary-foreground/80 hover:text-accent p-0 h-auto"
                  onClick={onOpenPlaybook}
                >
                  "From Pilot to Scale" Playbook
                </Button>
              </li>
              <li>
                <Button
                  variant="link"
                  className="text-primary-foreground/80 hover:text-accent p-0 h-auto"
                  onClick={onOpenFramework}
                >
                  Digital Champions Framework
                </Button>
              </li>
              <li>
                <Button
                  variant="link"
                  className="text-primary-foreground/80 hover:text-accent p-0 h-auto"
                  onClick={onOpenBoardBrief}
                >
                  Board Brief on AI & Digital Readiness 2025
                </Button>
              </li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/80">
              <li>
                <a href="https://calendly.com/prateek-karn-catallysts/30min" target="_blank" rel="noopener noreferrer" className="hover:text-accent transition-colors">
                  Book a Strategy Call
                </a>
              </li>
              <li>
                <Link to="/privacy-policy" className="hover:text-accent transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms-and-conditions" className="hover:text-accent transition-colors">
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm text-primary-foreground/60">
          <p>&copy; {new Date().getFullYear()} Catallyst Executive Education Institute. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};
