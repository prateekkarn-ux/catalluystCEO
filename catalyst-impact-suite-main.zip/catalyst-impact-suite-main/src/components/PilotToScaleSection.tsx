import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Search, Rocket, Trophy } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface PilotToScaleSectionProps {
  onOpenPlaybook: () => void;
}

export const PilotToScaleSection = ({ onOpenPlaybook }: PilotToScaleSectionProps) => {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2);
  const { ref: visualRef, isVisible: visualVisible } = useScrollAnimation(0.2);
  const { ref: statsRef, isVisible: statsVisible } = useScrollAnimation(0.2);

  return (
    <section className="py-20 bg-muted">
      <div className="container mx-auto px-6">
        <div 
          ref={headerRef}
          className={`max-w-4xl mx-auto text-center mb-12 transition-all duration-700 ${
            headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            From Pilot to Enterprise Impact
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Scaling innovation isn't about proof of concept – it's about proof of impact.
          </p>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Many digital initiatives stall after pilot phase. Our approach bridges the gap - embedding adoption, aligning leadership, and unlocking enterprise-wide transformation at speed.
          </p>
        </div>

        {/* Scaling Visual */}
        <div 
          ref={visualRef}
          className={`max-w-5xl mx-auto mb-12 transition-all duration-700 delay-150 ${
            visualVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <Card className="p-8 bg-card">
            <div className="flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="flex-1 text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-primary/10 mb-4">
                  <Search className="w-12 h-12 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-primary">Assess</h3>
                <p className="text-sm text-muted-foreground">Evaluate readiness</p>
              </div>

              <ArrowRight className="w-8 h-8 text-accent hidden md:block" />

              <div className="flex-1 text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-accent/20 mb-4">
                  <Rocket className="w-12 h-12 text-accent" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-accent">Activate</h3>
                <p className="text-sm text-muted-foreground">Launch & embed</p>
              </div>

              <ArrowRight className="w-8 h-8 text-accent hidden md:block" />

              <div className="flex-1 text-center">
                <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-amber-500/20 mb-4">
                  <Trophy className="w-12 h-12 text-amber-500" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-amber-500">Amplify</h3>
                <p className="text-sm text-muted-foreground">Scale enterprise-wide</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Key Stats */}
        <div 
          ref={statsRef}
          className={`grid md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-12 transition-all duration-700 delay-300 ${
            statsVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
          }`}
        >
          <Card className="p-6 text-center bg-card">
            <p className="text-4xl font-bold text-accent mb-2">95%</p>
            <p className="text-muted-foreground">of AI pilots never make it to production with measurable value</p>
            <p className="text-sm text-muted-foreground mt-2">— Forbes, 2025</p>
          </Card>

          <Card className="p-6 text-center bg-card">
            <p className="text-4xl font-bold text-accent mb-2">40%</p>
            <p className="text-muted-foreground">of executives say scaling digital initiatives is harder than starting them</p>
            <p className="text-sm text-muted-foreground mt-2">— McKinsey, 2025</p>
          </Card>
        </div>

        <div className="text-center">
          <Button
            size="lg"
            onClick={onOpenPlaybook}
            className="bg-accent hover:bg-accent/90 text-primary font-semibold px-8"
          >
            Download the Playbook
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  );
};
