import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, ArrowRight } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface CultureSectionProps {
  onOpenFramework: () => void;
}

export const CultureSection = ({ onOpenFramework }: CultureSectionProps) => {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2);
  const { ref: cardRef, isVisible: cardVisible } = useScrollAnimation(0.2);
  const { ref: gridRef, isVisible: gridVisible } = useScrollAnimation(0.2);

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div 
            ref={headerRef}
            className={`text-center mb-12 transition-all duration-700 ${
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Crack the Culture Code
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Culture is the Hidden Engine of Transformation
            </p>
          </div>

          <Card 
            ref={cardRef}
            className={`p-8 md:p-12 bg-primary text-primary-foreground mb-12 transition-all duration-700 delay-150 ${
              cardVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="flex items-start gap-4 mb-6">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center">
                  <Users className="w-8 h-8 text-accent" />
                </div>
              </div>
              <div>
                <p className="text-3xl font-bold text-accent mb-4">87%</p>
                <p className="text-lg">
                  of business leaders think digital transformation will disrupt their industry
                </p>
                <p className="text-sm text-primary-foreground/70 mt-2">— McKinsey</p>
              </div>
            </div>

            <div className="space-y-4 text-primary-foreground/90">
              <p className="text-lg leading-relaxed">
                Most transformation efforts stall because culture resists change. Middle management is often the 'frozen middle' that slows progress.
              </p>
              <p className="text-lg leading-relaxed">
                CEOs who embed adoption mechanisms like micro-behaviours and Digital Champions turn resistance into momentum.
              </p>
            </div>
          </Card>

          <div 
            ref={gridRef}
            className={`grid md:grid-cols-2 gap-6 mb-12 transition-all duration-700 delay-300 ${
              gridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <Card className="p-6 bg-card">
              <h3 className="text-xl font-semibold mb-4">The Challenge</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span>
                  <span>Leadership misalignment slows decision-making</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span>
                  <span>Middle management resistance ("frozen middle")</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span>
                  <span>Lack of clear change champions</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-destructive mt-1">•</span>
                  <span>No cultural mechanisms to sustain adoption</span>
                </li>
              </ul>
            </Card>

            <Card className="p-6 bg-accent/10 border-accent/30">
              <h3 className="text-xl font-semibold mb-4">The Solution</h3>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="text-accent mt-1">✓</span>
                  <span>Identify and empower Digital Champions</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent mt-1">✓</span>
                  <span>Embed micro-behaviours that drive adoption</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent mt-1">✓</span>
                  <span>Create peer-to-peer learning networks</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-accent mt-1">✓</span>
                  <span>Build a culture of experimentation</span>
                </li>
              </ul>
            </Card>
          </div>

          <div className="text-center">
            <Button
              size="lg"
              onClick={onOpenFramework}
              className="bg-accent hover:bg-accent/90 text-primary font-semibold px-8"
            >
              Request Your Digital Champions Framework
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
