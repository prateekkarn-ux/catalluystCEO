import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users2, ArrowRight } from "lucide-react";

interface LeadershipAlignmentSectionProps {
  onOpenStrategyCall: () => void;
}

export const LeadershipAlignmentSection = ({ onOpenStrategyCall }: LeadershipAlignmentSectionProps) => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Unify Your Leadership on Digital
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Leadership alignment is the catalyst for transformation
            </p>
            <p className="text-lg text-muted-foreground">
              We help CEOs convene their C-suite to create a single, powerful vision
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 mb-12">
            <Card className="p-8 bg-primary text-primary-foreground">
              <Users2 className="w-12 h-12 text-accent mb-6" />
              <h3 className="text-2xl font-bold mb-6">What You'll Gain</h3>
              <ul className="space-y-4">
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <span>A unified digital strategy co-created by your leadership team</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <span>Clear ownership and accountability for key initiatives</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <span>Faster decision-making when challenges arise</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent text-xl mt-1">•</span>
                  <span>A culture where transformation becomes everyone's business</span>
                </li>
              </ul>
            </Card>

            <Card className="p-8 bg-card">
              <div className="mb-8">
                <p className="text-4xl font-bold text-accent mb-4">1.7×</p>
                <p className="text-lg text-muted-foreground">
                  Organizations with aligned leadership are 1.7× more likely to deliver successful transformations
                </p>
                <p className="text-sm text-muted-foreground mt-2">— McKinsey</p>
              </div>

              <div className="space-y-4 text-muted-foreground">
                <p>
                  When your C-suite speaks with one voice, transformation accelerates. Misalignment creates friction, delays, and wasted resources.
                </p>
                <p>
                  Our leadership alignment sessions bring your team together to build shared understanding and commitment.
                </p>
              </div>
            </Card>
          </div>

          <Card className="p-8 bg-accent/10 border-accent/30 mb-8">
            <h3 className="text-xl font-bold mb-4 text-center">The Process</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-accent text-primary font-bold flex items-center justify-center mx-auto mb-4 text-xl">
                  1
                </div>
                <h4 className="font-semibold mb-2">Diagnose</h4>
                <p className="text-sm text-muted-foreground">Assess current alignment gaps and priorities</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-accent text-primary font-bold flex items-center justify-center mx-auto mb-4 text-xl">
                  2
                </div>
                <h4 className="font-semibold mb-2">Co-Create</h4>
                <p className="text-sm text-muted-foreground">Facilitate C-suite workshop to build shared vision</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 rounded-full bg-accent text-primary font-bold flex items-center justify-center mx-auto mb-4 text-xl">
                  3
                </div>
                <h4 className="font-semibold mb-2">Commit</h4>
                <p className="text-sm text-muted-foreground">Define clear roles, KPIs, and action plans</p>
              </div>
            </div>
          </Card>

          <div className="text-center">
            <Button
              size="lg"
              onClick={onOpenStrategyCall}
              className="bg-accent hover:bg-accent/90 text-primary font-semibold px-8"
            >
              Book Your 30-Min Leadership Alignment Consult
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
