import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, CheckCircle } from "lucide-react";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";

const heroImages = [hero1, hero2, hero3];

interface HeroSectionProps {
  onOpenBrochure: () => void;
  onOpenStrategyCall: () => void;
}

export const HeroSection = ({ onOpenBrochure, onOpenStrategyCall }: HeroSectionProps) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % heroImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative min-h-[90vh] flex items-center overflow-hidden">
      {/* Auto-rotating Background Images */}
      {heroImages.map((image, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentImageIndex ? "opacity-100" : "opacity-0"
          }`}
        >
          <img
            src={image}
            alt={`Executive meeting ${index + 1}`}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/85 to-primary/70" />
        </div>
      ))}

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 py-20">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-light tracking-tight text-primary-foreground mb-8 leading-[1.1] animate-fade-in">
            From Digital Investment to<br />
            <span className="font-medium">Boardroom Impact</span><br />
            <span className="text-accent font-medium">in 100 Days</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-primary-foreground/85 mb-12 leading-relaxed font-light animate-fade-in" style={{ animationDelay: "0.2s" }}>
            We help leaders deliver clear ROI, scale innovation beyond pilots, and align leadership—all within 100 days.
          </p>

          {/* Value Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <Card className="bg-white/95 backdrop-blur-sm p-8 border-accent/20 hover:border-accent/50 hover:shadow-elegant transition-all duration-500 animate-fade-in" style={{ animationDelay: "0.4s" }}>
              <CheckCircle className="w-7 h-7 text-accent mb-4" strokeWidth={1.5} />
              <h3 className="text-lg font-medium mb-3 text-foreground">Turn Digital & AI Investments into Measurable Growth</h3>
              <p className="text-muted-foreground leading-relaxed font-light">Transform technology investments into quantifiable business outcomes</p>
            </Card>
            
            <Card className="bg-white/95 backdrop-blur-sm p-8 border-accent/20 hover:border-accent/50 hover:shadow-elegant transition-all duration-500 animate-fade-in" style={{ animationDelay: "0.5s" }}>
              <CheckCircle className="w-7 h-7 text-accent mb-4" strokeWidth={1.5} />
              <h3 className="text-lg font-medium mb-3 text-foreground">Align Leadership, Scale Pilots, and Embed a Culture of Transformation</h3>
              <p className="text-muted-foreground leading-relaxed font-light">Build enterprise-wide adoption with unified leadership vision</p>
            </Card>
          </div>

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4 animate-fade-in" style={{ animationDelay: "0.6s" }}>
            <Button
              size="lg"
              onClick={onOpenBrochure}
              className="bg-accent hover:bg-accent/90 text-primary font-medium px-10 py-6 text-base shadow-elegant hover:shadow-glow transition-all duration-500 tracking-wide"
            >
              See ROI in Just 100 Days
              <ArrowRight className="ml-3 h-5 w-5" strokeWidth={1.5} />
            </Button>
            
            <Button
              size="lg"
              onClick={onOpenStrategyCall}
              className="bg-primary-foreground/95 text-primary hover:bg-primary-foreground border border-primary-foreground/30 px-10 py-6 text-base font-medium tracking-wide transition-all duration-500"
            >
              Book a CEO Strategy Call
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
