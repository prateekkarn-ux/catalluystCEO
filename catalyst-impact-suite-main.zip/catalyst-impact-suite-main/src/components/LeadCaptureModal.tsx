import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2 } from "lucide-react";

const personalEmailDomains = [
  "gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "aol.com",
  "icloud.com", "mail.com", "protonmail.com", "example.com", "test.com"
];

const leadSchema = z.object({
  name: z.string()
    .min(2, "Name must be at least 2 characters")
    .max(100, "Name must be less than 100 characters"),
  email: z.string()
    .email("Invalid email address")
    .refine((email) => {
      const domain = email.split("@")[1]?.toLowerCase();
      return !personalEmailDomains.includes(domain);
    }, "Please use a business email address"),
  organization: z.string()
    .min(2, "Organization name is required")
    .max(100, "Organization name must be less than 100 characters"),
  role: z.string()
    .min(2, "Role/Title is required")
    .max(100, "Role must be less than 100 characters"),
  phone: z.string()
    .optional()
    .refine((phone) => {
      if (!phone || phone === "") return true;
      return /^\+91\d{10}$/.test(phone);
    }, "Phone must be in format +91XXXXXXXXXX"),
});

type LeadFormData = z.infer<typeof leadSchema>;

interface LeadCaptureModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  resourceTitle: string;
  resourceDescription: string;
}

export const LeadCaptureModal = ({
  open,
  onOpenChange,
  resourceTitle,
  resourceDescription,
}: LeadCaptureModalProps) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<LeadFormData>({
    resolver: zodResolver(leadSchema),
  });

  const onSubmit = async (data: LeadFormData) => {
    setIsSubmitting(true);
    
    try {
      // TODO: Implement Google Sheets API integration
      // For now, simulate submission
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      console.log("Lead captured:", {
        ...data,
        resource: resourceTitle,
        timestamp: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
      });

      toast({
        title: "Success!",
        description: "Your download will begin shortly. Check your email for the resource.",
      });

      reset();
      onOpenChange(false);
      
      // Trigger download (placeholder)
      // In production, this would download the actual PDF
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit form. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">{resourceTitle}</DialogTitle>
          <DialogDescription className="text-base">
            {resourceDescription}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name *</Label>
            <Input
              id="name"
              {...register("name")}
              placeholder="John Doe"
              className={errors.name ? "border-destructive" : ""}
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Business Email *</Label>
            <Input
              id="email"
              type="email"
              {...register("email")}
              placeholder="john.doe@company.com"
              className={errors.email ? "border-destructive" : ""}
            />
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="organization">Organization *</Label>
            <Input
              id="organization"
              {...register("organization")}
              placeholder="Company Name"
              className={errors.organization ? "border-destructive" : ""}
            />
            {errors.organization && (
              <p className="text-sm text-destructive">{errors.organization.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role/Title *</Label>
            <Input
              id="role"
              {...register("role")}
              placeholder="CEO, CTO, etc."
              className={errors.role ? "border-destructive" : ""}
            />
            {errors.role && (
              <p className="text-sm text-destructive">{errors.role.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone (Optional)</Label>
            <Input
              id="phone"
              {...register("phone")}
              placeholder="+91XXXXXXXXXX"
              className={errors.phone ? "border-destructive" : ""}
            />
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone.message}</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full bg-accent hover:bg-accent/90 text-primary font-semibold"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting...
              </>
            ) : (
              "Download Now"
            )}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
};
