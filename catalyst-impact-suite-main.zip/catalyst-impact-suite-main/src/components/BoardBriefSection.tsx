import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, ArrowRight, CheckCircle } from "lucide-react";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface BoardBriefSectionProps {
  onOpenBoardBrief: () => void;
}

export const BoardBriefSection = ({ onOpenBoardBrief }: BoardBriefSectionProps) => {
  const { ref: headerRef, isVisible: headerVisible } = useScrollAnimation(0.2);
  const { ref: gridRef, isVisible: gridVisible } = useScrollAnimation(0.2);
  const { ref: perfectRef, isVisible: perfectVisible } = useScrollAnimation(0.2);

  return (
    <section className="py-20 bg-muted">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div 
            ref={headerRef}
            className={`text-center mb-12 transition-all duration-700 ${
              headerVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Board-Ready Insights
            </h2>
            <p className="text-xl text-muted-foreground">
              Boards don't want buzzwords. They want clarity, confidence, and proof.
            </p>
          </div>

          <div 
            ref={gridRef}
            className={`grid md:grid-cols-2 gap-8 mb-12 transition-all duration-700 delay-150 ${
              gridVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <Card className="p-8 bg-card">
              <FileText className="w-12 h-12 text-accent mb-6" />
              <h3 className="text-2xl font-bold mb-4">What's Included</h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span>Digital & AI Benchmarks for your industry</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span>Top Growth Levers to prioritize</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span>Risk & Governance Scorecards</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span>Future-Proof Scenarios and strategic options</span>
                </li>
                <li className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                  <span>Actionable Roadmap for next 100 days</span>
                </li>
              </ul>
            </Card>

            <Card className="p-8 bg-primary text-primary-foreground">
              <div className="mb-6">
                <p className="text-4xl font-bold text-accent mb-4">40-50%</p>
                <p className="text-lg">
                  improvement in board confidence when CEOs present data-driven transformation updates
                </p>
                <p className="text-sm text-primary-foreground/70 mt-2">— Harvard Business Review</p>
              </div>
              
              <div className="space-y-4 text-primary-foreground/90">
                <p className="leading-relaxed">
                  Boards expect CEOs to demonstrate how digital and AI investments translate to competitive advantage, risk mitigation, and growth.
                </p>
                <p className="leading-relaxed">
                  The Board Brief provides the clarity and evidence you need to lead with confidence.
                </p>
              </div>
            </Card>
          </div>

          <Card 
            ref={perfectRef}
            className={`p-8 bg-accent/10 border-accent/30 mb-8 transition-all duration-700 delay-300 ${
              perfectVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="text-center">
              <h3 className="text-2xl font-bold mb-4">Perfect For:</h3>
              <div className="flex flex-wrap justify-center gap-4">
                <span className="px-4 py-2 bg-card rounded-full text-sm font-medium">Quarterly Board Meetings</span>
                <span className="px-4 py-2 bg-card rounded-full text-sm font-medium">Strategy Reviews</span>
                <span className="px-4 py-2 bg-card rounded-full text-sm font-medium">Investor Updates</span>
                <span className="px-4 py-2 bg-card rounded-full text-sm font-medium">Leadership Planning</span>
              </div>
            </div>
          </Card>

          <div className="text-center">
            <Button
              size="lg"
              onClick={onOpenBoardBrief}
              className="bg-accent hover:bg-accent/90 text-primary font-semibold px-8"
            >
              Download the Board Brief
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
