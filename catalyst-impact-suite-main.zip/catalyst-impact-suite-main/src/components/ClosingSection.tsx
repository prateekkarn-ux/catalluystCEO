import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, ArrowRight } from "lucide-react";

interface ClosingSectionProps {
  onOpenStrategyCall: () => void;
}

export const ClosingSection = ({ onOpenStrategyCall }: ClosingSectionProps) => {
  return (
    <section className="py-20 bg-primary text-primary-foreground">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            Turn Your Digital Ambition into Boardroom Impact
          </h2>
          
          <div className="grid md:grid-cols-4 gap-4 mb-12">
            <Card className="p-6 bg-primary-foreground/5 border-accent/20 backdrop-blur-sm">
              <div className="text-3xl font-bold text-accent mb-2">1</div>
              <p className="text-base font-medium text-primary-foreground">ROI Clarity</p>
            </Card>
            <Card className="p-6 bg-primary-foreground/5 border-accent/20 backdrop-blur-sm">
              <div className="text-3xl font-bold text-accent mb-2">2</div>
              <p className="text-base font-medium text-primary-foreground">Scaling Transformation</p>
            </Card>
            <Card className="p-6 bg-primary-foreground/5 border-accent/20 backdrop-blur-sm">
              <div className="text-3xl font-bold text-accent mb-2">3</div>
              <p className="text-base font-medium text-primary-foreground">Cultural Alignment</p>
            </Card>
            <Card className="p-6 bg-primary-foreground/5 border-accent/20 backdrop-blur-sm">
              <div className="text-3xl font-bold text-accent mb-2">4</div>
              <p className="text-base font-medium text-primary-foreground">Board-Ready Insights</p>
            </Card>
          </div>

          <Card className="p-8 bg-card text-card-foreground mb-8">
            <Calendar className="w-16 h-16 text-accent mx-auto mb-6" />
            <h3 className="text-2xl font-bold mb-4">Book Your CEO Strategy Call</h3>
            <p className="text-lg text-muted-foreground mb-6">
              Not a generic consultation – a tailored discussion for leaders serious about delivering measurable impact in 100 days
            </p>
            <ul className="text-left max-w-md mx-auto space-y-3 mb-8 text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">✓</span>
                <span>Assess your current transformation readiness</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">✓</span>
                <span>Identify your top 3 scaling challenges</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">✓</span>
                <span>Outline a 100-day roadmap to measurable ROI</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-accent mt-1">✓</span>
                <span>Get actionable next steps for your leadership team</span>
              </li>
            </ul>
            
            <Button
              size="lg"
              onClick={onOpenStrategyCall}
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-8"
            >
              Schedule Your Strategy Call Now
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Card>

          <p className="text-primary-foreground/70">
            Join forward-thinking CEOs who are turning digital investments into competitive advantage
          </p>
        </div>
      </div>
    </section>
  );
};
