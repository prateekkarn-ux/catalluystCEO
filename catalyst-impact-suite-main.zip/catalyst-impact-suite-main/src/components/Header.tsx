import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import catallystLogo from "@/assets/catallyst-logo.png";

interface HeaderProps {
  onOpenStrategyCall: () => void;
}

export const Header = ({ onOpenStrategyCall }: HeaderProps) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <img src={catallystLogo} alt="Catallyst" className="h-12 w-auto" />
          </div>

          <Button
            onClick={onOpenStrategyCall}
            className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
          >
            <Calendar className="w-4 h-4 mr-2" />
            Book CEO Strategy Call
          </Button>
        </div>
      </div>
    </header>
  );
};
