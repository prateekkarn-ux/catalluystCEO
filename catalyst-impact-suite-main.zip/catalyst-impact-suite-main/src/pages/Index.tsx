import { useState } from "react";
import { Header } from "@/components/Header";
import { HeroSection } from "@/components/HeroSection";
import { PilotToScaleSection } from "@/components/PilotToScaleSection";
import { CultureSection } from "@/components/CultureSection";
import { BoardBriefSection } from "@/components/BoardBriefSection";
import { LeadershipAlignmentSection } from "@/components/LeadershipAlignmentSection";
import { ClosingSection } from "@/components/ClosingSection";
import { Footer } from "@/components/Footer";
import { LeadCaptureModal } from "@/components/LeadCaptureModal";

const Index = () => {
  const [brochureOpen, setBrochureOpen] = useState(false);
  const [playbookOpen, setPlaybookOpen] = useState(false);
  const [frameworkOpen, setFrameworkOpen] = useState(false);
  const [boardBriefOpen, setBoardBriefOpen] = useState(false);
  const [strategyCallOpen, setStrategyCallOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Header onOpenStrategyCall={() => setStrategyCallOpen(true)} />
      
      {/* Add padding-top to account for fixed header */}
      <div className="pt-16">
        <HeroSection 
          onOpenBrochure={() => setBrochureOpen(true)}
          onOpenStrategyCall={() => setStrategyCallOpen(true)}
        />
        
        <PilotToScaleSection onOpenPlaybook={() => setPlaybookOpen(true)} />
        
        <CultureSection onOpenFramework={() => setFrameworkOpen(true)} />
        
        <BoardBriefSection onOpenBoardBrief={() => setBoardBriefOpen(true)} />
        
        <LeadershipAlignmentSection onOpenStrategyCall={() => setStrategyCallOpen(true)} />
        
        <ClosingSection onOpenStrategyCall={() => setStrategyCallOpen(true)} />
        
        <Footer
          onOpenBrochure={() => setBrochureOpen(true)}
          onOpenPlaybook={() => setPlaybookOpen(true)}
          onOpenFramework={() => setFrameworkOpen(true)}
          onOpenBoardBrief={() => setBoardBriefOpen(true)}
        />
      </div>

      {/* Lead Capture Modals */}
      <LeadCaptureModal
        open={brochureOpen}
        onOpenChange={setBrochureOpen}
        resourceTitle="Lead the Shift, Shape What's Next"
        resourceDescription="Download our comprehensive brochure on digital transformation leadership and see how to deliver ROI in just 100 days."
      />

      <LeadCaptureModal
        open={playbookOpen}
        onOpenChange={setPlaybookOpen}
        resourceTitle="From Pilot to Scale Playbook"
        resourceDescription="Get the CEO's blueprint for turning proof-of-concept into enterprise-wide transformation with measurable impact."
      />

      <LeadCaptureModal
        open={frameworkOpen}
        onOpenChange={setFrameworkOpen}
        resourceTitle="Digital Champions Framework"
        resourceDescription="Learn how to identify and empower change agents across your organization to embed a culture of transformation."
      />

      <LeadCaptureModal
        open={boardBriefOpen}
        onOpenChange={setBoardBriefOpen}
        resourceTitle="Board Brief on AI & Digital Readiness 2025"
        resourceDescription="Access board-ready insights including benchmarks, growth levers, risk scorecards, and actionable roadmaps."
      />

      <LeadCaptureModal
        open={strategyCallOpen}
        onOpenChange={setStrategyCallOpen}
        resourceTitle="CEO Strategy Call"
        resourceDescription="Book your personalized strategy session to assess your transformation readiness and create a 100-day roadmap to measurable ROI."
      />
    </div>
  );
};

export default Index;
