import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function PrivacyPolicy() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <Link to="/">
          <Button variant="ghost" className="mb-8 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <article className="prose prose-slate max-w-none">
          <h1 className="text-4xl font-semibold text-foreground mb-2">Privacy Policy</h1>
          <p className="text-lg text-muted-foreground mb-12">Catallyst Executive Education Institute (CEEI)</p>
          <p className="text-sm text-muted-foreground mb-12">Last Updated: September 30, 2025</p>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">1. Contact Information</h2>
            <div className="text-muted-foreground space-y-1">
              <p>Catallyst Executive Education Institute (CEEI)</p>
              <p>9th Floor, Platina, G Block, Plot C 59</p>
              <p>Bandra Kurla Complex, Mumbai - 400 051, INDIA</p>
              <p>Tel: +91 22 68841503</p>
              <p>Email: exed@theceei.com</p>
              <p>Website: www.theceei.com</p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">2. Information We Collect</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Personal Information</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Full name, email address, phone number</li>
              <li>Professional details (job title, company, industry)</li>
              <li>Educational background and qualifications</li>
              <li>Billing and payment information</li>
              <li>Government-issued ID for verification purposes</li>
              <li>Emergency contact information</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Technical Information</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>IP address, browser type, device information</li>
              <li>Website usage data and analytics</li>
              <li>Cookies and tracking technologies</li>
              <li>Login credentials and session data</li>
              <li>Course progress and completion data</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Communication Data</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Correspondence and inquiries</li>
              <li>Feedback and survey responses</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">3. How We Use Your Information</h2>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Process course enrollments and payments</li>
              <li>Deliver educational content and services</li>
              <li>Communicate about programs and updates</li>
              <li>Provide customer support</li>
              <li>Issue certificates and credentials</li>
              <li>Conduct research and improve our services</li>
              <li>Comply with legal and regulatory requirements</li>
              <li>Marketing and promotional activities (with consent)</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">4. Information Sharing</h2>
            <p className="text-muted-foreground mb-4">We may share your information with:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Educational partners and guest faculty</li>
              <li>Payment processors and financial institutions</li>
              <li>Technology service providers</li>
              <li>Legal authorities when required by law</li>
              <li>Accreditation bodies for certification purposes</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">5. Data Security</h2>
            <p className="text-muted-foreground mb-4">We implement appropriate security measures including:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Encryption of sensitive data</li>
              <li>Secure servers and databases</li>
              <li>Regular security audits</li>
              <li>Access controls and authentication</li>
              <li>Staff training on data protection</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">6. Your Rights</h2>
            <p className="text-muted-foreground mb-4">Under applicable laws, you have the right to:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Access your personal information</li>
              <li>Correct inaccurate data</li>
              <li>Request deletion of your data</li>
              <li>Object to processing</li>
              <li>Data portability</li>
              <li>Withdraw consent</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">7. Cookies and Tracking</h2>
            <p className="text-muted-foreground mb-4">We use cookies for:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Website functionality</li>
              <li>Analytics and performance monitoring</li>
              <li>Personalized content delivery</li>
              <li>Marketing and advertising</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">8. Data Retention</h2>
            <p className="text-muted-foreground mb-4">We retain your information for:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Active students: Duration of enrollment plus 7 years</li>
              <li>Alumni: Indefinitely for alumni services</li>
              <li>Marketing data: Until consent is withdrawn</li>
              <li>Legal compliance: As required by law</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">9. International Transfers</h2>
            <p className="text-muted-foreground">
              Your data may be transferred to countries outside India for processing by our service providers, 
              with appropriate safeguards in place.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">10. Updates to This Policy</h2>
            <p className="text-muted-foreground">
              We may update this privacy policy periodically. Changes will be posted on our website with the updated date.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">11. Contact Us</h2>
            <p className="text-muted-foreground mb-4">For privacy-related inquiries, contact us at:</p>
            <div className="text-muted-foreground space-y-1">
              <p>Email: exed@theceei.com</p>
              <p>Phone: +91 22 68841503</p>
            </div>
          </section>
        </article>
      </div>
    </div>
  );
}
