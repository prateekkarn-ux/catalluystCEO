import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TermsAndConditions() {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-6 py-12 max-w-4xl">
        <Link to="/">
          <Button variant="ghost" className="mb-8 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        <article className="prose prose-slate max-w-none">
          <h1 className="text-4xl font-semibold text-foreground mb-2">Terms and Conditions</h1>
          <p className="text-lg text-muted-foreground mb-12">Catallyst Executive Education Institute (CEEI)</p>
          <p className="text-sm text-muted-foreground mb-12">Last Updated: September 30, 2025</p>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">1. Acceptance of Terms</h2>
            <p className="text-muted-foreground">
              By accessing or using the services of Catallyst Executive Education Institute (CEEI), you agree to be 
              bound by these Terms and Conditions. If you do not agree, please do not use our services.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">2. About CEEI</h2>
            <div className="text-muted-foreground space-y-1">
              <p>Catallyst Executive Education Institute (CEEI)</p>
              <p>9th Floor, Platina, G Block, Plot C 59</p>
              <p>Bandra Kurla Complex, Mumbai - 400 051, INDIA</p>
              <p>Tel: +91 22 68841503</p>
              <p>Email: exed@theceei.com</p>
              <p>Website: www.theceei.com</p>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">3. Services Provided</h2>
            <p className="text-muted-foreground">
              CEEI offers executive education programs, training courses, workshops, and related educational services 
              both online and offline.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">4. Enrollment and Registration</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Eligibility</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Participants must meet program-specific requirements</li>
              <li>Accurate information must be provided during registration</li>
              <li>CEEI reserves the right to verify credentials</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Registration Process</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Complete the application form</li>
              <li>Submit required documents</li>
              <li>Pay applicable fees</li>
              <li>Receive confirmation of enrollment</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">5. Fees and Payment</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Payment Terms</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Full payment required unless installment plan approved</li>
              <li>All fees are in Indian Rupees (INR) unless specified</li>
              <li>Payment methods: Bank transfer, credit/debit cards, cheques</li>
              <li>Late payment may result in program suspension</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Refund Policy</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Before program start: 80% refund if cancelled 30+ days prior</li>
              <li>15-29 days before: 50% refund</li>
              <li>Less than 15 days: No refund</li>
              <li>After program starts: No refund except in exceptional circumstances</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">6. Program Delivery</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Attendance Requirements</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Minimum 80% attendance required for certification</li>
              <li>Punctuality is mandatory</li>
              <li>Make-up sessions subject to availability</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Online Programs</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Stable internet connection required</li>
              <li>Technical requirements will be communicated</li>
              <li>Recording of sessions may occur</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">7. Intellectual Property</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">CEEI Content</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>All course materials, content, and resources are proprietary to CEEI</li>
              <li>Participants may use materials for personal learning only</li>
              <li>Reproduction, distribution, or commercial use prohibited</li>
            </ul>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Participant Content</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>CEEI may use participant feedback and testimonials</li>
              <li>Participants retain rights to their original work</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">8. Code of Conduct</h2>
            <p className="text-muted-foreground mb-4">Participants must:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Maintain professional behavior</li>
              <li>Respect fellow participants and faculty</li>
              <li>Not engage in disruptive activities</li>
              <li>Comply with all applicable laws</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">9. Certificates and Credentials</h2>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Certificates issued upon successful completion</li>
              <li>Requirements include attendance and assessment completion</li>
              <li>Certificates are non-transferable</li>
              <li>CEEI reserves the right to revoke certificates for misconduct</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">10. Limitation of Liability</h2>
            <p className="text-muted-foreground mb-4">
              CEEI's liability is limited to the fees paid for the specific program. We are not liable for:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Indirect, consequential, or punitive damages</li>
              <li>Loss of profits or business opportunities</li>
              <li>Technical issues beyond our control</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">11. Force Majeure</h2>
            <p className="text-muted-foreground">
              CEEI is not liable for delays or cancellations due to circumstances beyond our control, including 
              natural disasters, government actions, or pandemics.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">12. Privacy and Data Protection</h2>
            <p className="text-muted-foreground">
              Your personal information is governed by our Privacy Policy, which forms part of these terms.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">13. Modifications</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Program Changes</h3>
            <p className="text-muted-foreground mb-4">
              CEEI reserves the right to modify program content, schedules, and faculty.
            </p>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Terms Updates</h3>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>These terms may be updated periodically</li>
              <li>Continued use constitutes acceptance of changes</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">14. Termination</h2>
            <p className="text-muted-foreground mb-4">CEEI may terminate a participant's enrollment for:</p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2">
              <li>Violation of terms and conditions</li>
              <li>Non-payment of fees</li>
              <li>Disruptive or inappropriate behavior</li>
              <li>Providing false information</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">15. Dispute Resolution</h2>
            
            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Governing Law</h3>
            <p className="text-muted-foreground mb-4">These terms are governed by Indian law.</p>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Jurisdiction</h3>
            <p className="text-muted-foreground mb-4">
              All disputes shall be subject to the exclusive jurisdiction of Mumbai courts.
            </p>

            <h3 className="text-xl font-medium text-foreground mb-3 mt-6">Arbitration</h3>
            <p className="text-muted-foreground">
              Disputes may be resolved through arbitration as per Indian Arbitration and Conciliation Act.
            </p>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold text-foreground mb-4">16. Contact Information</h2>
            <p className="text-muted-foreground mb-4">For questions about these terms, contact us at:</p>
            <div className="text-muted-foreground space-y-1">
              <p>Email: exed@theceei.com</p>
              <p>Phone: +91 22 68841503</p>
            </div>
          </section>
        </article>
      </div>
    </div>
  );
}
